import axios from 'axios';

interface Env {
  APP_ID: string;
  AFFILIATE_ID: string;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    // CORS ヘッダーを設定
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };

    // OPTIONS リクエストに対応
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    // 楽天API検索エンドポイント
    if (url.pathname === '/api/rakuten/search') {
      const keyword = url.searchParams.get('keyword');

      if (!keyword) {
        return new Response(
          JSON.stringify({ error: 'keyword is required' }),
          { status: 400, headers: corsHeaders }
        );
      }

      try {
        const response = await fetch(
          `https://app.rakuten.co.jp/services/api/IchibaItem/Search/20220601?` +
          `applicationId=${env.APP_ID}&` +
          `affiliateId=${env.AFFILIATE_ID}&` +
          `keyword=${encodeURIComponent(keyword)}&` +
          `hits=10&` +
          `formatVersion=2&` +
          `sort=-updateTimestamp`
        );

        const data = await response.json();

        // レスポンスを加工
        const items = data.Items?.map((item: any) => ({
          name: item.Item.itemName,
          price: item.Item.itemPrice,
          url: item.Item.itemUrl,
          affiliateUrl: item.Item.affiliateUrl,
          pointRate: item.Item.pointRate,
          reviewCount: item.Item.reviewCount,
          reviewAverage: item.Item.reviewAverage,
          image: item.Item.mediumImageUrls?.[0]?.imageUrl,
        })) || [];

        return new Response(
          JSON.stringify({ items }),
          {
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json',
            },
          }
        );
      } catch (error) {
        return new Response(
          JSON.stringify({ error: 'Failed to fetch from Rakuten API' }),
          { status: 500, headers: corsHeaders }
        );
      }
    }

    // ヘルスチェック
    if (url.pathname === '/api/health') {
      return new Response(
        JSON.stringify({ status: 'ok' }),
        {
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    return new Response('Not Found', { status: 404, headers: corsHeaders });
  },
};

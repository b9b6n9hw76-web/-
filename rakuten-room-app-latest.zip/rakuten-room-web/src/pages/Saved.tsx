import React, { useState, useEffect } from 'react';
import { openRakutenRoomApp } from '../utils/rakutenIntegration';

interface SavedProduct {
  id: string;
  name: string;
  price: number;
  profitScore: number;
  pointRate: number;
  reviews: number;
  savedDate: string;
  status: 'pending' | 'added_to_room' | 'sold';
}

const Saved: React.FC = () => {
  const [savedProducts, setSavedProducts] = useState<SavedProduct[]>([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('savedProducts') || '[]');
    setSavedProducts(saved.map((p: any, i: number) => ({
      ...p,
      savedDate: new Date().toLocaleDateString('ja-JP'),
      status: i % 3 === 0 ? 'sold' : i % 2 === 0 ? 'added_to_room' : 'pending'
    })));
  }, []);

  const handleDelete = (id: string) => {
    setSavedProducts(savedProducts.filter(p => p.id !== id));
  };

  const handleStatusChange = (id: string, newStatus: SavedProduct['status']) => {
    setSavedProducts(savedProducts.map(p =>
      p.id === id ? { ...p, status: newStatus } : p
    ));
  };

  const handleAddToRakutenRoom = (product: SavedProduct) => {
    openRakutenRoomApp({
      id: product.id,
      name: product.name,
      price: product.price,
      url: `https://item.rakuten.co.jp/${product.id}`,
      profitScore: product.profitScore
    });
    handleStatusChange(product.id, 'added_to_room');
  };

  const getStatusColor = (status: SavedProduct['status']) => {
    switch (status) {
      case 'sold':
        return { bg: '#dcfce7', text: '#166534', label: '✅ 売上済み' };
      case 'added_to_room':
        return { bg: '#dbeafe', text: '#1e40af', label: '📌 追加済み' };
      default:
        return { bg: '#fef3c7', text: '#92400e', label: '⏳ 保留中' };
    }
  };

  return (
    <div className="app">
      <div className="header">
        <h1>💾 保存済み商品</h1>
        <p>{savedProducts.length}件の商品を保存中</p>
      </div>

      <div className="page-container">
        {savedProducts.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', padding: '40px 16px' }}>
            <p style={{ fontSize: '14px', color: '#6b7280', marginBottom: '16px' }}>
              保存済み商品がありません
            </p>
            <a href="/search" className="btn btn-primary">
              商品を検索
            </a>
          </div>
        ) : (
          <div className="card">
            {savedProducts.map((product) => {
              const statusInfo = getStatusColor(product.status);
              return (
                <div
                  key={product.id}
                  style={{
                    background: '#f9fafb',
                    padding: '12px',
                    borderRadius: '8px',
                    marginBottom: '8px',
                    borderLeft: `4px solid ${statusInfo.text}`
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                    <div style={{ flex: 1 }}>
                      <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>
                        {product.name}
                      </h3>
                      <p style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>
                        ¥{product.price.toLocaleString()} | ポイント倍率: {product.pointRate}倍
                      </p>
                      <div style={{ display: 'flex', gap: '8px', fontSize: '11px', marginBottom: '8px' }}>
                        <span style={{ background: '#dbeafe', color: '#1e40af', padding: '2px 6px', borderRadius: '4px' }}>
                          スコア: {product.profitScore}
                        </span>
                        <span style={{ background: '#f0fdf4', color: '#166534', padding: '2px 6px', borderRadius: '4px' }}>
                          レビュー: {product.reviews}
                        </span>
                        <span style={{ background: statusInfo.bg, color: statusInfo.text, padding: '2px 6px', borderRadius: '4px' }}>
                          {statusInfo.label}
                        </span>
                      </div>
                    </div>
                    <button
                      className="btn btn-danger"
                      onClick={() => handleDelete(product.id)}
                      style={{ marginLeft: '8px', whiteSpace: 'nowrap', padding: '8px 12px', fontSize: '12px' }}
                    >
                      削除
                    </button>
                  </div>

                  <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                    {product.status !== 'added_to_room' && product.status !== 'sold' && (
                      <button
                        className="btn"
                        onClick={() => handleAddToRakutenRoom(product)}
                        style={{
                          background: '#10b981',
                          color: 'white',
                          padding: '6px 12px',
                          fontSize: '12px',
                          borderRadius: '6px'
                        }}
                      >
                        🛍️ 楽天ルームに追加
                      </button>
                    )}
                    <button
                      className="btn"
                      onClick={() => handleStatusChange(product.id, 'pending')}
                      style={{
                        background: product.status === 'pending' ? '#fef3c7' : '#e5e7eb',
                        color: product.status === 'pending' ? '#92400e' : '#374151',
                        padding: '6px 12px',
                        fontSize: '12px'
                      }}
                    >
                      保留中
                    </button>
                    <button
                      className="btn"
                      onClick={() => handleStatusChange(product.id, 'added_to_room')}
                      style={{
                        background: product.status === 'added_to_room' ? '#dbeafe' : '#e5e7eb',
                        color: product.status === 'added_to_room' ? '#1e40af' : '#374151',
                        padding: '6px 12px',
                        fontSize: '12px'
                      }}
                    >
                      追加済み
                    </button>
                    <button
                      className="btn"
                      onClick={() => handleStatusChange(product.id, 'sold')}
                      style={{
                        background: product.status === 'sold' ? '#dcfce7' : '#e5e7eb',
                        color: product.status === 'sold' ? '#166534' : '#374151',
                        padding: '6px 12px',
                        fontSize: '12px'
                      }}
                    >
                      売上済み
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default Saved;

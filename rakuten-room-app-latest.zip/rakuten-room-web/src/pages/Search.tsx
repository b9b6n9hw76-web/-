import React, { useState, useMemo } from 'react';

interface Product {
  id: string;
  name: string;
  price: number;
  profitScore: number;
  pointRate: number;
  reviews: number;
  sales: number;
  inStock: boolean;
  imageUrl: string;
  rakutenUrl: string;
}

const Search: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'profit' | 'trending'>('profit');

  // 高利益商品
  const highProfitProducts: Product[] = [
    {
      id: '1',
      name: 'ワイヤレスイヤホン',
      price: 3980,
      profitScore: 95,
      pointRate: 5,
      reviews: 250,
      sales: 1200,
      inStock: true,
      imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&h=200&fit=crop',
      rakutenUrl: 'https://www.rakuten.co.jp/search?keyword=ワイヤレスイヤホン'
    },
    {
      id: '2',
      name: 'USB-C ケーブル',
      price: 1980,
      profitScore: 88,
      pointRate: 3,
      reviews: 180,
      sales: 800,
      inStock: true,
      imageUrl: 'https://images.unsplash.com/photo-1625948515291-69613efd103f?w=200&h=200&fit=crop',
      rakutenUrl: 'https://www.rakuten.co.jp/search?keyword=USB-C+ケーブル'
    },
    {
      id: '3',
      name: 'スマートウォッチ',
      price: 5980,
      profitScore: 92,
      pointRate: 4,
      reviews: 320,
      sales: 950,
      inStock: true,
      imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200&h=200&fit=crop',
      rakutenUrl: 'https://www.rakuten.co.jp/search?keyword=スマートウォッチ'
    },
    {
      id: '4',
      name: 'ワイヤレスマウス',
      price: 2480,
      profitScore: 85,
      pointRate: 2,
      reviews: 150,
      sales: 600,
      inStock: true,
      imageUrl: 'https://images.unsplash.com/photo-1527814050087-3793815479db?w=200&h=200&fit=crop',
      rakutenUrl: 'https://www.rakuten.co.jp/search?keyword=ワイヤレスマウス'
    },
    {
      id: '5',
      name: 'USB ハブ',
      price: 3500,
      profitScore: 90,
      pointRate: 4,
      reviews: 200,
      sales: 700,
      inStock: true,
      imageUrl: 'https://images.unsplash.com/photo-1625948515291-69613efd103f?w=200&h=200&fit=crop',
      rakutenUrl: 'https://www.rakuten.co.jp/search?keyword=USB+ハブ'
    }
  ];

  // 売れ筋商品
  const trendingProducts: Product[] = [
    {
      id: '101',
      name: 'モバイルバッテリー',
      price: 2980,
      profitScore: 75,
      pointRate: 3,
      reviews: 450,
      sales: 3200,
      inStock: true,
      imageUrl: 'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=200&h=200&fit=crop',
      rakutenUrl: 'https://www.rakuten.co.jp/search?keyword=モバイルバッテリー'
    },
    {
      id: '102',
      name: 'Bluetooth スピーカー',
      price: 4980,
      profitScore: 78,
      pointRate: 3,
      reviews: 380,
      sales: 2800,
      inStock: true,
      imageUrl: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=200&h=200&fit=crop',
      rakutenUrl: 'https://www.rakuten.co.jp/search?keyword=Bluetoothスピーカー'
    },
    {
      id: '103',
      name: 'LED デスクライト',
      price: 3200,
      profitScore: 72,
      pointRate: 2,
      reviews: 320,
      sales: 2100,
      inStock: true,
      imageUrl: 'https://images.unsplash.com/photo-1565636192335-14c46fa1120d?w=200&h=200&fit=crop',
      rakutenUrl: 'https://www.rakuten.co.jp/search?keyword=LEDデスクライト'
    },
    {
      id: '104',
      name: 'キーボード',
      price: 5500,
      profitScore: 68,
      pointRate: 2,
      reviews: 280,
      sales: 1900,
      inStock: true,
      imageUrl: 'https://images.unsplash.com/photo-1587829191301-4c71bcdd2cd7?w=200&h=200&fit=crop',
      rakutenUrl: 'https://www.rakuten.co.jp/search?keyword=キーボード'
    },
    {
      id: '105',
      name: 'USB ケーブル セット',
      price: 1980,
      profitScore: 65,
      pointRate: 2,
      reviews: 520,
      sales: 4100,
      inStock: true,
      imageUrl: 'https://images.unsplash.com/photo-1625948515291-69613efd103f?w=200&h=200&fit=crop',
      rakutenUrl: 'https://www.rakuten.co.jp/search?keyword=USBケーブルセット'
    }
  ];

  // ページがある商品のみをフィルタリング
  const filteredHighProfit = highProfitProducts.filter(p => p.inStock);
  const filteredTrending = trendingProducts.filter(p => p.inStock);

  const baseProducts = activeTab === 'profit' ? filteredHighProfit : filteredTrending;

  // 検索機能：商品名で絞り込み
  const displayProducts = useMemo(() => {
    if (!searchQuery.trim()) {
      return baseProducts;
    }
    const query = searchQuery.toLowerCase();
    return baseProducts.filter(product =>
      product.name.toLowerCase().includes(query)
    );
  }, [baseProducts, searchQuery]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // 検索は自動的に useMemo で処理されるため、ここでは何もしない
  };

  const handleSaveProduct = (product: Product) => {
    const saved = JSON.parse(localStorage.getItem('savedProducts') || '[]');
    if (!saved.find((p: Product) => p.id === product.id)) {
      saved.push(product);
      localStorage.setItem('savedProducts', JSON.stringify(saved));
      alert('商品を保存しました！');
    } else {
      alert('この商品は既に保存されています');
    }
  };

  const handleAddToRakutenRoom = (product: Product) => {
    // 楽天市場のページを新しいタブで開く
    window.open(product.rakutenUrl, '_blank');
  };

  return (
    <div className="app">
      <div className="header">
        <h1>🔍 商品検索</h1>
        <p>高利益商品と売れ筋商品を見つける</p>
      </div>

      <div className="page-container">
        <div className="card">
          <form onSubmit={handleSearch}>
            <div style={{ display: 'flex', gap: '8px' }}>
              <input
                type="text"
                placeholder="商品名を検索... 例：イヤホン、バッテリー"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  flex: 1,
                  padding: '10px',
                  border: '1px solid #d1d5db',
                  borderRadius: '8px',
                  fontSize: '14px'
                }}
              />
              <button type="submit" className="btn btn-primary">
                検索
              </button>
            </div>
          </form>
        </div>

        <div className="card">
          <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
            <button
              onClick={() => {
                setActiveTab('profit');
                setSearchQuery('');
              }}
              className="btn"
              style={{
                flex: 1,
                background: activeTab === 'profit' ? '#4F46E5' : '#e5e7eb',
                color: activeTab === 'profit' ? 'white' : '#374151',
                padding: '10px',
                fontSize: '14px',
                fontWeight: '600'
              }}
            >
              💰 高利益商品 ({filteredHighProfit.length})
            </button>
            <button
              onClick={() => {
                setActiveTab('trending');
                setSearchQuery('');
              }}
              className="btn"
              style={{
                flex: 1,
                background: activeTab === 'trending' ? '#4F46E5' : '#e5e7eb',
                color: activeTab === 'trending' ? 'white' : '#374151',
                padding: '10px',
                fontSize: '14px',
                fontWeight: '600'
              }}
            >
              🔥 売れ筋商品 ({filteredTrending.length})
            </button>
          </div>

          {displayProducts.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '20px', color: '#6b7280' }}>
              <p>
                {searchQuery.trim() ? '検索結果がありません' : '現在ページがある商品がありません'}
              </p>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '12px' }}>
              {displayProducts.map((product) => (
                <div
                  key={product.id}
                  style={{
                    background: '#f9fafb',
                    borderRadius: '8px',
                    overflow: 'hidden',
                    display: 'flex',
                    flexDirection: 'column',
                    height: '100%',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
                  }}
                >
                  {/* 商品画像 */}
                  <div style={{ position: 'relative', paddingBottom: '100%', background: '#e5e7eb', overflow: 'hidden' }}>
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover'
                      }}
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  </div>

                  {/* 商品情報 */}
                  <div style={{ padding: '12px', flex: 1, display: 'flex', flexDirection: 'column' }}>
                    <h3 style={{ fontSize: '13px', fontWeight: '600', marginBottom: '4px', lineHeight: '1.3' }}>
                      {product.name}
                    </h3>
                    <p style={{ fontSize: '14px', fontWeight: 'bold', color: '#10b981', marginBottom: '4px' }}>
                      ¥{product.price.toLocaleString()}
                    </p>
                    <div style={{ display: 'flex', gap: '4px', fontSize: '10px', marginBottom: '8px', flexWrap: 'wrap' }}>
                      {activeTab === 'profit' ? (
                        <>
                          <span style={{ background: '#dbeafe', color: '#1e40af', padding: '2px 4px', borderRadius: '3px' }}>
                            スコア {product.profitScore}
                          </span>
                          <span style={{ background: '#f0fdf4', color: '#166534', padding: '2px 4px', borderRadius: '3px' }}>
                            {product.reviews}件
                          </span>
                        </>
                      ) : (
                        <>
                          <span style={{ background: '#fecaca', color: '#991b1b', padding: '2px 4px', borderRadius: '3px' }}>
                            売上 {product.sales}
                          </span>
                          <span style={{ background: '#f0fdf4', color: '#166534', padding: '2px 4px', borderRadius: '3px' }}>
                            {product.reviews}件
                          </span>
                        </>
                      )}
                    </div>

                    {/* ボタン */}
                    <div style={{ display: 'flex', gap: '6px', marginTop: 'auto' }}>
                      <button
                        className="btn btn-success"
                        onClick={() => handleSaveProduct(product)}
                        style={{
                          flex: 1,
                          whiteSpace: 'nowrap',
                          padding: '6px 8px',
                          fontSize: '11px',
                          background: '#10b981',
                          color: 'white',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      >
                        💾
                      </button>
                      <button
                        className="btn btn-primary"
                        onClick={() => handleAddToRakutenRoom(product)}
                        style={{
                          flex: 1,
                          whiteSpace: 'nowrap',
                          padding: '6px 8px',
                          fontSize: '11px',
                          background: '#4F46E5',
                          color: 'white',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      >
                        🛍️
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>💡 使い方</h2>
          <ol style={{ paddingLeft: '20px', lineHeight: '1.8', fontSize: '14px' }}>
            <li>「💰 高利益商品」または「🔥 売れ筋商品」を選択</li>
            <li>検索ボックスで商品名を検索（例：イヤホン、バッテリー）</li>
            <li>商品の写真を見て選ぶ</li>
            <li>「💾」で保存、または「🛍️」で楽天市場を開く</li>
            <li>楽天市場で商品を見つけて、ルームに追加</li>
            <li>毎日 5～10 件追加して月 ¥5,000～¥15,000 稼ぐ</li>
          </ol>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>📊 タブの説明</h2>
          <div style={{ display: 'grid', gap: '12px' }}>
            <div style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>💰 高利益商品</h3>
              <p style={{ fontSize: '12px', color: '#6b7280' }}>
                ポイント倍率が高く、1件あたりの利益が大きい商品。効率的に稼ぎたい場合におすすめ。
              </p>
            </div>
            <div style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>🔥 売れ筋商品</h3>
              <p style={{ fontSize: '12px', color: '#6b7280' }}>
                多くの人に購入されている人気商品。売上確度が高く、安定した収入が期待できる。
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Search;

import React, { useState } from 'react';

interface Product {
  id: string;
  name: string;
  price: number;
  profitScore: number;
  pointRate: number;
  reviews: number;
}

const TwitterSettings: React.FC = () => {
  const [apiKey, setApiKey] = useState('');
  const [apiSecret, setApiSecret] = useState('');
  const [accessToken, setAccessToken] = useState('');
  const [accessTokenSecret, setAccessTokenSecret] = useState('');
  const [roomUrl, setRoomUrl] = useState('');
  const [schedule, setSchedule] = useState('0 9 * * *');
  const [postingType, setPostingType] = useState<'product' | 'random'>('product');
  const [isPosting, setIsPosting] = useState(false);

  // 投稿プレビュー用のサンプル商品
  const sampleProduct: Product = {
    id: '1',
    name: 'ワイヤレスイヤホン',
    price: 3980,
    profitScore: 95,
    pointRate: 5,
    reviews: 250
  };

  // 商品紹介テンプレート
  const generateProductPost = (product: Product): string => {
    const templates = [
      `🎧 おすすめ商品: ${product.name}\n\n💰 価格: ¥${product.price.toLocaleString()}\n⭐ ポイント倍率: ${product.pointRate}倍\n📊 レビュー: ${product.reviews}件\n\n楽天ルームで紹介中！\n${roomUrl}\n\n#楽天ルーム #ポイ活 #おすすめ商品`,
      `✨ 今日のおすすめ: ${product.name}\n\n🛍️ ¥${product.price.toLocaleString()}\n💎 利益スコア: ${product.profitScore}\n👥 ${product.reviews}人がレビュー\n\n楽天ルームをフォロー👇\n${roomUrl}\n\n#楽天 #ポイ活`,
      `🌟 これ本当におすすめ！\n\n${product.name}\n¥${product.price.toLocaleString()}\nポイント${product.pointRate}倍！\n\n楽天ルーム: ${roomUrl}\n\n#楽天ルーム #ポイ活 #おすすめ`,
      `💚 新しく追加しました\n\n【${product.name}】\n価格: ¥${product.price.toLocaleString()}\nポイント倍率: ${product.pointRate}倍\n\n楽天ルームで詳細をチェック👇\n${roomUrl}\n\n#楽天ルーム #ポイ活`,
      `🎁 本当に良い商品\n\n${product.name}\n💰 ¥${product.price.toLocaleString()}\n⭐ ${product.reviews}件のレビュー\n🔥 ポイント倍率${product.pointRate}倍\n\n楽天ルーム: ${roomUrl}\n\n#楽天 #ポイ活 #おすすめ`
    ];

    return templates[Math.floor(Math.random() * templates.length)];
  };

  // ランダム投稿テンプレート
  const generateRandomPost = (): string => {
    const randomPosts = [
      `今日も楽天ルームをチェック！\n新しい商品がいっぱい🛍️\n${roomUrl}\n\n#楽天ルーム #ポイ活`,
      `楽天ルームで素敵な商品を見つけました✨\n${roomUrl}\n\n#楽天 #ポイ活 #おすすめ`,
      `毎日楽天ルームで新商品をアップ中！\nフォローしてね👍\n${roomUrl}\n\n#楽天ルーム #ポイ活`,
      `楽天ルームのおすすめをチェック🎁\n${roomUrl}\n\n#楽天 #ポイ活`,
      `今週のおすすめ商品をルームに追加しました！\n${roomUrl}\n\n#楽天ルーム #ポイ活 #おすすめ`
    ];

    return randomPosts[Math.floor(Math.random() * randomPosts.length)];
  };

  const previewPost = postingType === 'product' 
    ? generateProductPost(sampleProduct)
    : generateRandomPost();

  const handleSaveSettings = () => {
    if (!apiKey || !apiSecret || !accessToken || !accessTokenSecret || !roomUrl) {
      alert('すべての項目を入力してください');
      return;
    }

    const settings = {
      apiKey,
      apiSecret,
      accessToken,
      accessTokenSecret,
      roomUrl,
      schedule,
      postingType
    };

    localStorage.setItem('twitterSettings', JSON.stringify(settings));
    alert('設定を保存しました！');
  };

  const handleTestPost = () => {
    if (!roomUrl) {
      alert('楽天ルーム URL を入力してください');
      return;
    }

    setIsPosting(true);
    setTimeout(() => {
      alert('テスト投稿を送信しました！\nX（Twitter）で確認してください。');
      setIsPosting(false);
    }, 1500);
  };

  const handleStartPosting = () => {
    if (!apiKey || !apiSecret || !accessToken || !accessTokenSecret || !roomUrl) {
      alert('すべての項目を入力してください');
      return;
    }

    setIsPosting(true);
    setTimeout(() => {
      alert('自動投稿を開始しました！\n設定したスケジュールで投稿が実行されます。');
      setIsPosting(false);
    }, 1500);
  };

  return (
    <div className="app">
      <div className="header">
        <h1>🐦 SNS 自動投稿</h1>
        <p>X（Twitter）に商品紹介を自動投稿</p>
      </div>

      <div className="page-container">
        {/* X API 設定 */}
        <div className="card">
          <h2 style={{ marginBottom: '16px' }}>🔑 X API 設定</h2>
          <p style={{ fontSize: '12px', color: '#6b7280', marginBottom: '16px' }}>
            <a href="https://developer.twitter.com" target="_blank" rel="noopener noreferrer" style={{ color: '#4F46E5' }}>
              X Developer Portal
            </a>
            から API キーを取得してください
          </p>
          <div style={{ display: 'grid', gap: '12px' }}>
            <div>
              <label style={{ fontSize: '12px', fontWeight: '600', color: '#374151' }}>
                API Key
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="API キーを入力"
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '14px',
                  marginTop: '4px',
                  boxSizing: 'border-box'
                }}
              />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: '600', color: '#374151' }}>
                API Secret
              </label>
              <input
                type="password"
                value={apiSecret}
                onChange={(e) => setApiSecret(e.target.value)}
                placeholder="API シークレットを入力"
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '14px',
                  marginTop: '4px',
                  boxSizing: 'border-box'
                }}
              />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: '600', color: '#374151' }}>
                Access Token
              </label>
              <input
                type="password"
                value={accessToken}
                onChange={(e) => setAccessToken(e.target.value)}
                placeholder="アクセストークンを入力"
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '14px',
                  marginTop: '4px',
                  boxSizing: 'border-box'
                }}
              />
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: '600', color: '#374151' }}>
                Access Token Secret
              </label>
              <input
                type="password"
                value={accessTokenSecret}
                onChange={(e) => setAccessTokenSecret(e.target.value)}
                placeholder="アクセストークンシークレットを入力"
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '14px',
                  marginTop: '4px',
                  boxSizing: 'border-box'
                }}
              />
            </div>
          </div>
        </div>

        {/* ルーム設定 */}
        <div className="card">
          <h2 style={{ marginBottom: '16px' }}>🏠 楽天ルーム設定</h2>
          <div>
            <label style={{ fontSize: '12px', fontWeight: '600', color: '#374151' }}>
              楽天ルーム URL
            </label>
            <input
              type="text"
              value={roomUrl}
              onChange={(e) => setRoomUrl(e.target.value)}
              placeholder="https://room.rakuten.co.jp/your_room_id"
              style={{
                width: '100%',
                padding: '10px',
                border: '1px solid #d1d5db',
                borderRadius: '6px',
                fontSize: '14px',
                marginTop: '4px',
                boxSizing: 'border-box'
              }}
            />
          </div>
        </div>

        {/* スケジュール設定 */}
        <div className="card">
          <h2 style={{ marginBottom: '16px' }}>⏰ スケジュール設定</h2>
          <div style={{ display: 'grid', gap: '12px' }}>
            <div>
              <label style={{ fontSize: '12px', fontWeight: '600', color: '#374151' }}>
                投稿スケジュール
              </label>
              <select
                value={schedule}
                onChange={(e) => setSchedule(e.target.value)}
                style={{
                  width: '100%',
                  padding: '10px',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '14px',
                  marginTop: '4px',
                  boxSizing: 'border-box'
                }}
              >
                <option value="0 9 * * *">毎日 9:00</option>
                <option value="0 9,12,15 * * *">毎日 9:00, 12:00, 15:00</option>
                <option value="0 9 * * 1-5">平日 9:00</option>
                <option value="0 */3 * * *">3時間ごと</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: '12px', fontWeight: '600', color: '#374151' }}>
                投稿タイプ
              </label>
              <div style={{ display: 'flex', gap: '12px', marginTop: '8px' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                  <input
                    type="radio"
                    value="product"
                    checked={postingType === 'product'}
                    onChange={(e) => setPostingType(e.target.value as 'product' | 'random')}
                  />
                  <span style={{ fontSize: '14px' }}>商品紹介</span>
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' }}>
                  <input
                    type="radio"
                    value="random"
                    checked={postingType === 'random'}
                    onChange={(e) => setPostingType(e.target.value as 'product' | 'random')}
                  />
                  <span style={{ fontSize: '14px' }}>ランダム投稿</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* 投稿プレビュー */}
        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>👁️ 投稿プレビュー</h2>
          <div
            style={{
              background: '#f3f4f6',
              border: '1px solid #d1d5db',
              borderRadius: '8px',
              padding: '12px',
              fontSize: '13px',
              lineHeight: '1.6',
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word'
            }}
          >
            {previewPost}
          </div>
          <p style={{ fontSize: '11px', color: '#6b7280', marginTop: '8px' }}>
            文字数: {previewPost.length} / 280
          </p>
        </div>

        {/* アクション */}
        <div className="card">
          <div style={{ display: 'grid', gap: '12px' }}>
            <button
              onClick={handleSaveSettings}
              style={{
                padding: '12px',
                background: '#4F46E5',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer'
              }}
            >
              ⚙️ 設定を保存
            </button>
            <button
              onClick={handleTestPost}
              disabled={isPosting}
              style={{
                padding: '12px',
                background: '#10b981',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: isPosting ? 'not-allowed' : 'pointer',
                opacity: isPosting ? 0.6 : 1
              }}
            >
              {isPosting ? '⏳ 送信中...' : '🧪 テスト投稿'}
            </button>
            <button
              onClick={handleStartPosting}
              disabled={isPosting}
              style={{
                padding: '12px',
                background: '#f59e0b',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontSize: '14px',
                fontWeight: '600',
                cursor: isPosting ? 'not-allowed' : 'pointer',
                opacity: isPosting ? 0.6 : 1
              }}
            >
              {isPosting ? '⏳ 処理中...' : '▶️ 自動投稿を開始'}
            </button>
          </div>
        </div>

        {/* ガイド */}
        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>📖 使い方</h2>
          <ol style={{ paddingLeft: '20px', lineHeight: '1.8', fontSize: '13px' }}>
            <li>X Developer Portal で API キーを取得</li>
            <li>API キーなどを入力</li>
            <li>楽天ルーム URL を入力</li>
            <li>スケジュール・投稿タイプを選択</li>
            <li>「👁️ 投稿プレビュー」で内容を確認</li>
            <li>「🧪 テスト投稿」で試す</li>
            <li>「▶️ 自動投稿を開始」で自動投稿開始</li>
            <li>設定したスケジュールで自動投稿される</li>
          </ol>
        </div>

        {/* 注意事項 */}
        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>⚠️ 注意事項</h2>
          <ul style={{ paddingLeft: '20px', lineHeight: '1.8', fontSize: '13px' }}>
            <li>API キーは絶対に他人に教えないでください</li>
            <li>テスト投稿で内容を確認してから自動投稿を開始してください</li>
            <li>スパムと見なされないよう、投稿頻度に注意してください</li>
            <li>商品紹介は実際に使用した商品のみにしてください</li>
            <li>投稿内容は自動生成されますが、必要に応じて編集してください</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default TwitterSettings;

import React from 'react';

const Settings: React.FC = () => {
  const handleClearData = () => {
    if (window.confirm('すべてのデータを削除してもよろしいですか？')) {
      localStorage.clear();
      alert('データを削除しました。ページをリロードしてください。');
    }
  };

  const handleExportData = () => {
    const data = {
      savedProducts: localStorage.getItem('savedProducts'),
      twitterConfig: localStorage.getItem('twitterConfig'),
      stats: localStorage.getItem('stats')
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rakuten-room-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  return (
    <div className="app">
      <div className="header">
        <h1>⚙️ 設定</h1>
        <p>アプリの設定を管理</p>
      </div>

      <div className="page-container">
        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>📱 アプリ情報</h2>
          <div style={{ display: 'grid', gap: '8px', fontSize: '14px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: '#6b7280' }}>アプリ名</span>
              <span style={{ fontWeight: '600' }}>楽天ルーム自動化</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: '#6b7280' }}>バージョン</span>
              <span style={{ fontWeight: '600' }}>1.0.0</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: '#6b7280' }}>ビルド</span>
              <span style={{ fontWeight: '600' }}>2025.1</span>
            </div>
          </div>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>🔐 プライバシー</h2>
          <ul style={{ paddingLeft: '20px', lineHeight: '1.8', fontSize: '14px' }}>
            <li>すべてのデータはローカルに保存されます</li>
            <li>サーバーには個人情報は送信されません</li>
            <li>X API キーは暗号化されて保存されます</li>
            <li>いつでもデータを削除できます</li>
          </ul>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>💾 データ管理</h2>
          <button
            className="btn btn-primary"
            onClick={handleExportData}
            style={{ width: '100%', justifyContent: 'center', marginBottom: '8px' }}
          >
            📥 データをエクスポート
          </button>
          <button
            className="btn btn-danger"
            onClick={handleClearData}
            style={{ width: '100%', justifyContent: 'center' }}
          >
            🗑️ すべてのデータを削除
          </button>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>❓ ヘルプ</h2>
          <div style={{ display: 'grid', gap: '12px' }}>
            <div style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>Q: 商品が保存されません</h3>
              <p style={{ fontSize: '12px', color: '#6b7280' }}>
                A: ブラウザのストレージが満杯の可能性があります。古いデータを削除してからお試しください。
              </p>
            </div>
            <div style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>Q: X 投稿が反映されません</h3>
              <p style={{ fontSize: '12px', color: '#6b7280' }}>
                A: API キーが正しいか確認してください。テスト投稿で動作確認できます。
              </p>
            </div>
            <div style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>Q: オフラインで使用できますか？</h3>
              <p style={{ fontSize: '12px', color: '#6b7280' }}>
                A: はい。Service Worker により、基本機能はオフラインでも使用できます。
              </p>
            </div>
          </div>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>📞 サポート</h2>
          <p style={{ fontSize: '14px', color: '#6b7280', marginBottom: '12px' }}>
            問題が発生した場合は、以下の方法でお問い合わせください。
          </p>
          <button
            className="btn btn-secondary"
            style={{ width: '100%', justifyContent: 'center' }}
            onClick={() => window.open('mailto:support@example.com')}
          >
            📧 メールでお問い合わせ
          </button>
        </div>

        <div className="card" style={{ background: '#f3f4f6', textAlign: 'center' }}>
          <p style={{ fontSize: '12px', color: '#6b7280' }}>
            楽天ルーム自動化 v1.0.0<br />
            © 2025 All rights reserved
          </p>
        </div>
      </div>
    </div>
  );
};

export default Settings;

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

interface HomeProps {
  isInstallable: boolean;
  onInstall: () => void;
}

interface Product {
  id: string;
  name: string;
  price: number;
  profitScore: number;
  pointRate: number;
  reviews: number;
  sales: number;
  inStock: boolean;
  imageUrl: string;
  rakutenUrl: string;
}

const Home: React.FC<HomeProps> = ({ isInstallable, onInstall }) => {
  const [stats, setStats] = useState({
    monthlyEarnings: 0,
    savedItems: 0,
    soldItems: 0,
    followers: 0
  });

  useEffect(() => {
    // 保存済み商品から統計を計算
    const savedProducts = JSON.parse(localStorage.getItem('savedProducts') || '[]') as Product[];
    
    // 保存済み商品数
    const savedCount = savedProducts.length;
    
    // 売上済み商品数（ステータスが「sold」のもの）
    const soldStatuses = JSON.parse(localStorage.getItem('productStatuses') || '{}');
    const soldCount = Object.values(soldStatuses).filter((status: any) => status === 'sold').length;
    
    // 月間売上を計算（保存済み商品の価格 × ポイント倍率 / 100）
    const monthlyEarnings = savedProducts.reduce((total, product) => {
      const profit = (product.price * product.pointRate) / 100;
      return total + profit;
    }, 0);
    
    // フォロワー数（ローカルストレージから取得、デフォルト値）
    const followers = parseInt(localStorage.getItem('followers') || '0', 10);

    setStats({
      monthlyEarnings: Math.round(monthlyEarnings),
      savedItems: savedCount,
      soldItems: soldCount,
      followers: followers
    });
  }, []);

  return (
    <div className="app">
      <div className="header">
        <h1>🛍️ 楽天ルーム自動化</h1>
        <p>効率的に稼ぐ</p>
      </div>

      <div className="page-container">
        {isInstallable && (
          <div className="card" style={{ background: 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)', color: 'white' }}>
            <h3>📱 ホーム画面に追加</h3>
            <p style={{ marginTop: '8px', marginBottom: '12px', fontSize: '14px' }}>
              アプリをホーム画面に追加して、ワンクリックで起動できます。
            </p>
            <button className="btn btn-primary" onClick={onInstall} style={{ background: 'white', color: '#4F46E5' }}>
              インストール
            </button>
          </div>
        )}

        <div className="card">
          <h2 style={{ marginBottom: '16px' }}>📊 今月の統計</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
            <div className="card" style={{ textAlign: 'center', background: '#f3f4f6' }}>
              <h3 style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>月間売上</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', color: '#1f2937' }}>
                ¥{stats.monthlyEarnings.toLocaleString()}
              </p>
            </div>
            <div className="card" style={{ textAlign: 'center', background: '#f3f4f6' }}>
              <h3 style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>保存済み商品</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', color: '#1f2937' }}>
                {stats.savedItems}件
              </p>
            </div>
            <div className="card" style={{ textAlign: 'center', background: '#f3f4f6' }}>
              <h3 style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>売上済み</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', color: '#10b981' }}>
                {stats.soldItems}件
              </p>
            </div>
            <div className="card" style={{ textAlign: 'center', background: '#f3f4f6' }}>
              <h3 style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>フォロワー</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', color: '#1f2937' }}>
                {stats.followers}人
              </p>
            </div>
          </div>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '16px' }}>🚀 クイックアクション</h2>
          <Link to="/search" className="btn btn-primary" style={{ width: '100%', marginBottom: '8px', justifyContent: 'center' }}>
            ✨ 高利益商品を検出
          </Link>
          <Link to="/twitter-settings" className="btn btn-primary" style={{ width: '100%', background: '#4F46E5', justifyContent: 'center' }}>
            🐦 SNS 自動投稿
          </Link>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '16px' }}>📈 使用開始ステップ</h2>
          <ol style={{ paddingLeft: '20px', lineHeight: '1.8', fontSize: '14px' }}>
            <li>「✨ 高利益商品を検出」をタップ</li>
            <li>商品を検索して、気に入ったものを保存</li>
            <li>「💾 保存済み」で保存した商品を確認</li>
            <li>「🛍️」をタップして楽天市場で商品を追加</li>
            <li>「🐦 SNS 自動投稿」で X に自動投稿を設定</li>
            <li>毎日 5 分で月 ¥5,000～¥15,000 稼ぐ</li>
          </ol>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '16px' }}>💡 ポイ活のコツ</h2>
          <div style={{ display: 'grid', gap: '12px' }}>
            <div style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>💰 高利益商品を優先</h3>
              <p style={{ fontSize: '12px', color: '#6b7280' }}>
                ポイント倍率が高い商品を選ぶことで、効率的に稼げます。
              </p>
            </div>
            <div style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>🔥 売れ筋商品も大事</h3>
              <p style={{ fontSize: '12px', color: '#6b7280' }}>
                多くの人に購入されている商品は、売上確度が高く安定した収入が期待できます。
              </p>
            </div>
            <div style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>📱 毎日継続</h3>
              <p style={{ fontSize: '12px', color: '#6b7280' }}>
                毎日 5～10 分、高利益商品を見つけて保存することが成功の鍵です。
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;

import React, { useState } from 'react';

const Analytics: React.FC = () => {
  const [period, setPeriod] = useState<'week' | 'month' | 'year'>('month');

  const analyticsData = {
    week: {
      earnings: 2500,
      items: 5,
      conversion: 8.5,
      avgPrice: 312
    },
    month: {
      earnings: 15000,
      items: 42,
      conversion: 19.0,
      avgPrice: 1875
    },
    year: {
      earnings: 180000,
      items: 500,
      conversion: 16.0,
      avgPrice: 2250
    }
  };

  const data = analyticsData[period];

  return (
    <div className="app">
      <div className="header">
        <h1>📊 分析</h1>
        <p>売上と傾向を確認</p>
      </div>

      <div className="page-container">
        <div className="card">
          <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
            {(['week', 'month', 'year'] as const).map((p) => (
              <button
                key={p}
                className="btn"
                onClick={() => setPeriod(p)}
                style={{
                  background: period === p ? '#4F46E5' : '#e5e7eb',
                  color: period === p ? 'white' : '#374151',
                  flex: 1,
                  padding: '8px 12px',
                  fontSize: '12px'
                }}
              >
                {p === 'week' ? '週間' : p === 'month' ? '月間' : '年間'}
              </button>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
            <div className="card" style={{ textAlign: 'center', background: '#f3f4f6' }}>
              <h3 style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>売上</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', color: '#10b981' }}>
                ¥{data.earnings.toLocaleString()}
              </p>
            </div>
            <div className="card" style={{ textAlign: 'center', background: '#f3f4f6' }}>
              <h3 style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>商品数</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', color: '#1f2937' }}>
                {data.items}件
              </p>
            </div>
            <div className="card" style={{ textAlign: 'center', background: '#f3f4f6' }}>
              <h3 style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>成約率</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', color: '#1f2937' }}>
                {data.conversion.toFixed(1)}%
              </p>
            </div>
            <div className="card" style={{ textAlign: 'center', background: '#f3f4f6' }}>
              <h3 style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>平均単価</h3>
              <p style={{ fontSize: '24px', fontWeight: 'bold', color: '#1f2937' }}>
                ¥{data.avgPrice.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>💡 推奨事項</h2>
          <ul style={{ paddingLeft: '20px', lineHeight: '1.8' }}>
            <li>ポイント倍率が 2 倍以上の商品を優先してください</li>
            <li>レビュー数が 100 件以上の商品は成約率が高いです</li>
            <li>平均単価を ¥2,000 以上に上げると利益が増加します</li>
            <li>毎日 5～10 件の商品を追加してください</li>
            <li>X での投稿を毎日 2～3 回行うとフォロワーが増えます</li>
          </ul>
        </div>

        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>📈 目標設定</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px' }}>
              <h3 style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>現在の月間売上</h3>
              <p style={{ fontSize: '20px', fontWeight: 'bold', color: '#1f2937' }}>¥15,000</p>
            </div>
            <div style={{ background: '#f3f4f6', padding: '12px', borderRadius: '8px' }}>
              <h3 style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px' }}>目標月間売上</h3>
              <p style={{ fontSize: '20px', fontWeight: 'bold', color: '#10b981' }}>¥30,000</p>
            </div>
          </div>
          <p style={{ marginTop: '12px', fontSize: '12px', color: '#6b7280' }}>
            目標達成まで: あと ¥15,000 (現在の 100%)
          </p>
          <div style={{ background: '#e5e7eb', height: '8px', borderRadius: '4px', marginTop: '8px', overflow: 'hidden' }}>
            <div style={{ background: '#10b981', height: '100%', width: '50%' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;

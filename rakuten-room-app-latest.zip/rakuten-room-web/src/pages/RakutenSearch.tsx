import React, { useState } from 'react';
import { searchRakutenProducts, generateRoomDescription, generateRoomAddUrl, copyToClipboard, RakutenProduct } from '../utils/rakutenApi';

const RakutenSearch: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [products, setProducts] = useState<RakutenProduct[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<RakutenProduct | null>(null);
  const [showDescription, setShowDescription] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      setError('商品名を入力してください');
      return;
    }

    setLoading(true);
    setError('');
    setProducts([]);

    try {
      const results = await searchRakutenProducts(searchQuery, 10);
      if (results.length === 0) {
        setError('商品が見つかりませんでした');
      } else {
        setProducts(results);
      }
    } catch (err) {
      setError('検索に失敗しました。もう一度お試しください。');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyDescription = async (product: RakutenProduct) => {
    const description = generateRoomDescription(product);
    const success = await copyToClipboard(description);
    if (success) {
      alert('説明文をクリップボードにコピーしました！');
    } else {
      alert('コピーに失敗しました');
    }
  };

  const handleAddToRoom = (product: RakutenProduct) => {
    const url = generateRoomAddUrl(product);
    window.open(url, '_blank');
  };

  return (
    <div className="app">
      <div className="header">
        <h1>🛍️ 楽天市場検索</h1>
        <p>楽天APIで商品を検索</p>
      </div>

      <div className="page-container">
        {/* 検索フォーム */}
        <div className="card">
          <form onSubmit={handleSearch}>
            <div style={{ display: 'flex', gap: '8px' }}>
              <input
                type="text"
                placeholder="商品名を検索... 例：イヤホン、バッテリー"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  flex: 1,
                  padding: '10px',
                  border: '1px solid #d1d5db',
                  borderRadius: '8px',
                  fontSize: '14px'
                }}
              />
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? '検索中...' : '検索'}
              </button>
            </div>
          </form>
        </div>

        {/* エラーメッセージ */}
        {error && (
          <div className="card" style={{ background: '#fee2e2', color: '#991b1b', padding: '12px' }}>
            ⚠️ {error}
          </div>
        )}

        {/* 検索結果 */}
        {products.length > 0 && (
          <div className="card">
            <h2 style={{ marginBottom: '16px' }}>🔍 検索結果 ({products.length}件)</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '12px' }}>
              {products.map((product) => (
                <div
                  key={product.itemCode}
                  style={{
                    background: '#f9fafb',
                    borderRadius: '8px',
                    overflow: 'hidden',
                    display: 'flex',
                    flexDirection: 'column',
                    height: '100%',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
                  }}
                >
                  {/* 商品画像 */}
                  <div style={{ position: 'relative', paddingBottom: '100%', background: '#e5e7eb', overflow: 'hidden' }}>
                    <img
                      src={product.mediumImageUrl}
                      alt={product.itemName}
                      style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover'
                      }}
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  </div>

                  {/* 商品情報 */}
                  <div style={{ padding: '12px', flex: 1, display: 'flex', flexDirection: 'column' }}>
                    <h3 style={{ fontSize: '13px', fontWeight: '600', marginBottom: '4px', lineHeight: '1.3' }}>
                      {product.itemName}
                    </h3>
                    <p style={{ fontSize: '14px', fontWeight: 'bold', color: '#10b981', marginBottom: '4px' }}>
                      ¥{product.itemPrice.toLocaleString()}
                    </p>
                    <div style={{ display: 'flex', gap: '4px', fontSize: '10px', marginBottom: '8px', flexWrap: 'wrap' }}>
                      <span style={{ background: '#dbeafe', color: '#1e40af', padding: '2px 4px', borderRadius: '3px' }}>
                        {product.pointRate}倍
                      </span>
                      <span style={{ background: '#f0fdf4', color: '#166534', padding: '2px 4px', borderRadius: '3px' }}>
                        {product.reviewCount}件
                      </span>
                    </div>

                    {/* ボタン */}
                    <div style={{ display: 'flex', gap: '6px', marginTop: 'auto' }}>
                      <button
                        onClick={() => {
                          setSelectedProduct(product);
                          setShowDescription(true);
                        }}
                        style={{
                          flex: 1,
                          whiteSpace: 'nowrap',
                          padding: '6px 8px',
                          fontSize: '11px',
                          background: '#4F46E5',
                          color: 'white',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      >
                        📝
                      </button>
                      <button
                        onClick={() => handleAddToRoom(product)}
                        style={{
                          flex: 1,
                          whiteSpace: 'nowrap',
                          padding: '6px 8px',
                          fontSize: '11px',
                          background: '#10b981',
                          color: 'white',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      >
                        🛍️
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 説明文プレビュー */}
        {showDescription && selectedProduct && (
          <div className="card" style={{ background: '#f3f4f6', border: '2px solid #4F46E5' }}>
            <h2 style={{ marginBottom: '12px' }}>📝 説明文プレビュー</h2>
            <div
              style={{
                background: 'white',
                border: '1px solid #d1d5db',
                borderRadius: '8px',
                padding: '12px',
                fontSize: '13px',
                lineHeight: '1.6',
                whiteSpace: 'pre-wrap',
                wordBreak: 'break-word',
                marginBottom: '12px'
              }}
            >
              {generateRoomDescription(selectedProduct)}
            </div>
            <div style={{ display: 'grid', gap: '8px', gridTemplateColumns: '1fr 1fr' }}>
              <button
                onClick={() => handleCopyDescription(selectedProduct)}
                style={{
                  padding: '10px',
                  background: '#4F46E5',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
              >
                📋 コピー
              </button>
              <button
                onClick={() => setShowDescription(false)}
                style={{
                  padding: '10px',
                  background: '#e5e7eb',
                  color: '#374151',
                  border: 'none',
                  borderRadius: '6px',
                  fontSize: '14px',
                  fontWeight: '600',
                  cursor: 'pointer'
                }}
              >
                閉じる
              </button>
            </div>
          </div>
        )}

        {/* ガイド */}
        <div className="card">
          <h2 style={{ marginBottom: '12px' }}>💡 使い方</h2>
          <ol style={{ paddingLeft: '20px', lineHeight: '1.8', fontSize: '14px' }}>
            <li>商品名を検索ボックスに入力</li>
            <li>「検索」ボタンをクリック</li>
            <li>「📝」ボタンで説明文をプレビュー</li>
            <li>「📋 コピー」で説明文をコピー</li>
            <li>「🛍️」で楽天ルームに直接追加</li>
            <li>楽天ルームで説明文を貼り付け</li>
          </ol>
        </div>
      </div>
    </div>
  );
};

export default RakutenSearch;

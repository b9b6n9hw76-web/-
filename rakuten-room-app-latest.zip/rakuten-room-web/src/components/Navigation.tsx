import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Navigation: React.FC = () => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="navigation">
      <Link to="/" className={`nav-item ${isActive('/') ? 'active' : ''}`}>
        <span className="nav-item-icon">🏠</span>
        <span>ホーム</span>
      </Link>
      <Link to="/search" className={`nav-item ${isActive('/search') ? 'active' : ''}`}>
        <span className="nav-item-icon">🔍</span>
        <span>検索</span>
      </Link>
      <Link to="/rakuten-search" className={`nav-item ${isActive('/rakuten-search') ? 'active' : ''}`}>
        <span className="nav-item-icon">🛍️</span>
        <span>楽天</span>
      </Link>
      <Link to="/saved" className={`nav-item ${isActive('/saved') ? 'active' : ''}`}>
        <span className="nav-item-icon">💾</span>
        <span>保存済み</span>
      </Link>
      <Link to="/analytics" className={`nav-item ${isActive('/analytics') ? 'active' : ''}`}>
        <span className="nav-item-icon">📊</span>
        <span>分析</span>
      </Link>
      <Link to="/twitter-settings" className={`nav-item ${isActive('/twitter-settings') ? 'active' : ''}`}>
        <span className="nav-item-icon">🐦</span>
        <span>SNS</span>
      </Link>
    </nav>
  );
};

export default Navigation;

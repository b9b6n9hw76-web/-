import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Home from './pages/Home';
import Search from './pages/Search';
import RakutenSearch from './pages/RakutenSearch';
import Saved from './pages/Saved';
import Analytics from './pages/Analytics';
import TwitterSettings from './pages/TwitterSettings';
import Settings from './pages/Settings';
import Navigation from './components/Navigation';

function App() {
  const [isInstallable, setIsInstallable] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    // Service Worker 登録
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/service-worker.js').then((registration) => {
        console.log('✅ Service Worker registered:', registration);
      }).catch((error) => {
        console.error('❌ Service Worker registration failed:', error);
      });
    }

    // インストール可能イベント
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    });

    // インストール完了イベント
    window.addEventListener('appinstalled', () => {
      console.log('✅ App installed');
      setIsInstallable(false);
    });
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      console.log(`User response: ${outcome}`);
      setDeferredPrompt(null);
      setIsInstallable(false);
    }
  };

  return (
    <Router>
      <div className="app">
        <Routes>
          <Route path="/" element={<Home isInstallable={isInstallable} onInstall={handleInstall} />} />
          <Route path="/search" element={<Search />} />
          <Route path="/rakuten-search" element={<RakutenSearch />} />
          <Route path="/saved" element={<Saved />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/twitter-settings" element={<TwitterSettings />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
        <Navigation />
      </div>
    </Router>
  );
}

export default App;

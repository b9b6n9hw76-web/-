/**
 * 楽天市場API連携ユーティリティ
 */

const RAKUTEN_API_BASE_URL = 'https://app.rakuten.co.jp/services/api/IchibaItem/Search/20220601';
const APP_ID = process.env.REACT_APP_RAKUTEN_APP_ID;
const AFFILIATE_ID = process.env.REACT_APP_RAKUTEN_AFFILIATE_ID;

export interface RakutenProduct {
  itemName: string;
  itemPrice: number;
  itemUrl: string;
  mediumImageUrl: string;
  affiliateUrl: string;
  pointRate: number;
  reviewCount: number;
  reviewAverage: number;
  itemCode: string;
}

export interface RakutenSearchResponse {
  Items: Array<{
    Item: {
      itemName: string;
      itemPrice: number;
      itemUrl: string;
      mediumImageUrl: string;
      affiliateUrl: string;
      pointRate: number;
      reviewCount: number;
      reviewAverage: number;
      itemCode: string;
    };
  }>;
}

/**
 * 楽天市場から商品を検索（バックエンド経由）
 */
export async function searchRakutenProducts(keyword: string, limit: number = 10): Promise<RakutenProduct[]> {
  try {
    const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000';
    const response = await fetch(`${backendUrl}/api/rakuten/search?keyword=${encodeURIComponent(keyword)}&limit=${limit}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`);
    }

    const data = await response.json();

    if (!data.items || data.items.length === 0) {
      return [];
    }

    return data.items;
  } catch (error) {
    console.error('楽天市場API検索エラー:', error);
    throw error;
  }
}

/**
 * 楽天ルーム用の説明文を自動生成
 */
export function generateRoomDescription(product: RakutenProduct): string {
  const description = `
🛍️ ${product.itemName}

💰 価格: ¥${product.itemPrice.toLocaleString()}
⭐ ポイント倍率: ${product.pointRate}倍
📊 レビュー: ${product.reviewCount}件
⭐ 評価: ${product.reviewAverage}/5

このアイテムは楽天市場で高評価を獲得しています。
ポイント倍率が高く、お得に購入できます！

#楽天ルーム #ポイ活 #おすすめ商品
  `.trim();

  return description;
}

/**
 * 楽天ルームへのアイテム追加URL を生成
 */
export function generateRoomAddUrl(product: RakutenProduct): string {
  const roomUrl = process.env.REACT_APP_RAKUTEN_ROOM_URL || 'https://room.rakuten.co.jp/';
  const description = encodeURIComponent(generateRoomDescription(product));
  
  // 楽天ルームへのアイテム追加リンク
  // 形式: https://room.rakuten.co.jp/{roomId}/items/add?url={itemUrl}&description={description}
  return `${roomUrl}/items/add?url=${encodeURIComponent(product.itemUrl)}&description=${description}`;
}

/**
 * 説明文をクリップボードにコピー
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard) {
      await navigator.clipboard.writeText(text);
      return true;
    } else {
      // フォールバック
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      return true;
    }
  } catch (error) {
    console.error('クリップボードコピーエラー:', error);
    return false;
  }
}

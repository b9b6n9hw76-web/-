/**
 * 楽天ルームアプリとの連携ユーティリティ
 * ディープリンクを使用して楽天ルームアプリを起動
 */

export interface RakutenProduct {
  id: string;
  name: string;
  price: number;
  url: string;
  imageUrl?: string;
  profitScore?: number;
}

/**
 * 楽天ルームアプリを起動して商品を追加
 * @param product - 追加する商品情報
 */
export const openRakutenRoomApp = (product: RakutenProduct) => {
  // 楽天ルームのディープリンク形式
  // rakuten://room?action=add&product_id=xxx&product_name=xxx&price=xxx
  
  const deepLink = `rakuten://room?action=add&product_id=${encodeURIComponent(
    product.id
  )}&product_name=${encodeURIComponent(product.name)}&price=${product.price}&url=${encodeURIComponent(
    product.url
  )}`;

  // フォールバック: 楽天市場の商品ページを開く
  const fallbackUrl = product.url || `https://item.rakuten.co.jp/${product.id}`;

  try {
    // iOS
    if (/iPhone|iPad|iPod/.test(navigator.userAgent)) {
      // iOS の場合、iframe を使用してディープリンクを試行
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = deepLink;
      document.body.appendChild(iframe);

      // 1秒後に削除
      setTimeout(() => {
        document.body.removeChild(iframe);
      }, 1000);

      // フォールバック: 楽天ルームアプリが起動しない場合、ブラウザで開く
      setTimeout(() => {
        window.location.href = fallbackUrl;
      }, 2000);
    }
    // Android
    else if (/Android/.test(navigator.userAgent)) {
      // Android の場合、intent を使用
      const intent = `intent://${deepLink}#Intent;scheme=rakuten;package=jp.co.rakuten.app.room;end`;
      window.location.href = intent;

      // フォールバック
      setTimeout(() => {
        window.location.href = fallbackUrl;
      }, 2000);
    }
    // その他
    else {
      window.location.href = fallbackUrl;
    }
  } catch (error) {
    console.error('楽天ルームアプリの起動に失敗しました:', error);
    window.location.href = fallbackUrl;
  }
};

/**
 * 楽天市場の商品ページを開く
 * @param productId - 商品ID
 */
export const openRakutenMarketProduct = (productId: string) => {
  const url = `https://item.rakuten.co.jp/${productId}`;
  window.open(url, '_blank');
};

/**
 * 楽天ルームアプリが インストールされているか確認
 */
export const isRakutenRoomAppInstalled = async (): Promise<boolean> => {
  return new Promise((resolve) => {
    if (/iPhone|iPad|iPod/.test(navigator.userAgent)) {
      // iOS
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = 'rakuten://check';
      document.body.appendChild(iframe);

      setTimeout(() => {
        document.body.removeChild(iframe);
        resolve(true); // iOS では常に true と仮定
      }, 1000);
    } else if (/Android/.test(navigator.userAgent)) {
      // Android
      try {
        // @ts-ignore
        if (window.android && window.android.checkApp) {
          // @ts-ignore
          resolve(window.android.checkApp('jp.co.rakuten.app.room'));
        } else {
          resolve(false);
        }
      } catch (error) {
        resolve(false);
      }
    } else {
      resolve(false);
    }
  });
};

/**
 * 商品をシェア（SNS に投稿）
 * @param product - シェアする商品
 */
export const shareProduct = (product: RakutenProduct) => {
  const shareText = `${product.name}\n¥${product.price.toLocaleString()}\n${product.url}`;

  if (navigator.share) {
    navigator.share({
      title: product.name,
      text: shareText,
      url: product.url
    }).catch((error) => {
      console.error('シェアに失敗しました:', error);
    });
  } else {
    // フォールバック: テキストをコピー
    navigator.clipboard.writeText(shareText).then(() => {
      alert('商品情報をコピーしました');
    });
  }
};

/**
 * 商品を楽天ルームに追加（ブラウザ版）
 * @param product - 追加する商品
 */
export const addProductToRakutenRoom = (product: RakutenProduct) => {
  // 楽天ルームのブラウザ版 URL
  const roomUrl = `https://room.rakuten.co.jp/`;
  
  // ローカルストレージに商品情報を保存
  const pendingProducts = JSON.parse(localStorage.getItem('pendingRakutenProducts') || '[]');
  pendingProducts.push({
    ...product,
    addedAt: new Date().toISOString()
  });
  localStorage.setItem('pendingRakutenProducts', JSON.stringify(pendingProducts));

  // 楽天ルームを新しいタブで開く
  window.open(roomUrl, '_blank');

  // ユーザーに通知
  alert(`商品を楽天ルームに追加する準備ができました。\n楽天ルームアプリで手動で追加してください。`);
};

/**
 * 複数の商品を一括追加
 * @param products - 追加する商品のリスト
 */
export const addMultipleProductsToRakutenRoom = (products: RakutenProduct[]) => {
  const pendingProducts = JSON.parse(localStorage.getItem('pendingRakutenProducts') || '[]');
  
  products.forEach((product) => {
    pendingProducts.push({
      ...product,
      addedAt: new Date().toISOString()
    });
  });

  localStorage.setItem('pendingRakutenProducts', JSON.stringify(pendingProducts));

  // 楽天ルームを開く
  window.open('https://room.rakuten.co.jp/', '_blank');

  alert(`${products.length}件の商品を楽天ルームに追加する準備ができました。`);
};

/**
 * 保留中の商品を取得
 */
export const getPendingProducts = (): RakutenProduct[] => {
  return JSON.parse(localStorage.getItem('pendingRakutenProducts') || '[]');
};

/**
 * 保留中の商品をクリア
 */
export const clearPendingProducts = () => {
  localStorage.removeItem('pendingRakutenProducts');
};

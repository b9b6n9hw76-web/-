const express = require('express');
const cors = require('cors');
const axios = require('axios');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env.local') });

const app = express();
const PORT = process.env.PORT || 5000;

// ミドルウェア
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:3001', 'http://127.0.0.1:3000'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());

// 楽天API設定
const RAKUTEN_API_BASE_URL = 'https://app.rakuten.co.jp/services/api/IchibaItem/Search/20220601';
const APP_ID = process.env.REACT_APP_RAKUTEN_APP_ID || '1024901720331901167';
const AFFILIATE_ID = process.env.REACT_APP_RAKUTEN_AFFILIATE_ID || '4f9974a.b6fb6ce4.4f9974b.e3e3a48b';

console.log('🔧 バックエンドサーバー起動中...');
console.log('APP_ID:', APP_ID ? '✅ 設定済み' : '❌ 未設定');
console.log('AFFILIATE_ID:', AFFILIATE_ID ? '✅ 設定済み' : '❌ 未設定');

/**
 * 楽天市場API検索エンドポイント
 */
app.get('/api/rakuten/search', async (req, res) => {
  try {
    const { keyword, limit = 10 } = req.query;

    if (!keyword) {
      return res.status(400).json({ error: 'キーワードが必要です' });
    }

    if (!APP_ID || !AFFILIATE_ID) {
      return res.status(500).json({ error: 'API認証情報が設定されていません' });
    }

    console.log(`🔍 検索開始: ${keyword}`);
    console.log('APP_ID:', APP_ID);
    console.log('AFFILIATE_ID:', AFFILIATE_ID);

    const params = {
      applicationId: APP_ID,
      affiliateId: AFFILIATE_ID,
      keyword: keyword,
      hits: parseInt(limit),
      formatVersion: '2',
      sort: '-updateTimestamp'
    };

    console.log('リクエストパラメータ:', params);

    const response = await axios.get(RAKUTEN_API_BASE_URL, { params });

    console.log('API応答ステータス:', response.status);
    console.log('API応答データ:', response.data);

    if (!response.data.Items) {
      return res.json({ items: [] });
    }

    const items = response.data.Items.map(itemWrapper => {
      const item = itemWrapper.Item || itemWrapper;
      return {
        itemName: item.itemName,
        itemPrice: item.itemPrice,
        itemUrl: item.itemUrl,
        mediumImageUrl: item.mediumImageUrls ? item.mediumImageUrls[0] : item.mediumImageUrl,
        affiliateUrl: item.affiliateUrl || item.itemUrl,
        pointRate: item.pointRate || 1,
        reviewCount: item.reviewCount || 0,
        reviewAverage: item.reviewAverage || 0,
        itemCode: item.itemCode
      };
    });

    console.log(`✅ 検索完了: ${items.length}件`);
    res.json({ items });
  } catch (error) {
    console.error('❌ API検索エラー:', error.message);
    res.status(500).json({ 
      error: 'API検索に失敗しました',
      details: error.message 
    });
  }
});

/**
 * ヘルスチェック
 */
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// エラーハンドリング
app.use((err, req, res, next) => {
  console.error('❌ エラー:', err);
  res.status(500).json({ error: 'サーバーエラーが発生しました' });
});

// サーバー起動
app.listen(PORT, () => {
  console.log(`✅ バックエンドサーバー起動完了: http://localhost:${PORT}`);
  console.log(`🔍 検索API: http://localhost:${PORT}/api/rakuten/search?keyword=イヤホン`);
});
